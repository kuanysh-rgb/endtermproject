package project;
import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class Main {
    private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private static Order order = new Order();
    private static PayStrategy strategy;
    public static  void main(String[] args) throws IOException, SQLException, ClassNotFoundException, IllegalAccessException, InstantiationException {
        while (!order.isClosed()) {
            int category;
            double cost = 0;

            String continueChoice;
            do {
                System.out.print("Please, select a category:" + "\n" +
                        "1 - Mobile phones" + "\n" +
                        "2 - Laptops" + "\n" +
                        "3 - Computer components" + "\n");
                int choice = Integer.parseInt(reader.readLine());
                String url = "jdbc:mysql://localhost:3307/admin?serverTimezone=UTC";
                String user = "root";
                String password = "7854";
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection myConn = DriverManager.getConnection(url,user,password);
                Statement query = myConn.createStatement();

                if(choice == 1){
                    String a = "Mobile phones";
                    String sql = "select * from products WHERE category_name = " + "'" + a + "'";

                    ResultSet rs = query.executeQuery(sql);
                    while(rs.next()){
                        System.out.print(rs.getString("product_id"));
                        System.out.print(". ");
                        System.out.print(rs.getString("product_name"));
                        System.out.print(" price is ");
                        System.out.println(rs.getString("product_price"));
                    }
                }
                else if(choice == 2){
                    String b = "Laptops";
                    String sql2 = "select * from products WHERE category_name = " + "'" + b + "'";

                    ResultSet rs = query.executeQuery(sql2);
                    while(rs.next()){
                        System.out.print(rs.getString("product_id"));
                        System.out.print(". ");
                        System.out.print(rs.getString("product_name"));
                        System.out.print(" price is ");
                        System.out.println(rs.getString("product_price"));
                    }
                }
                else{
                    String c = "Components";
                    String sql3 = "select * from products WHERE category_name = " + "'" + c + "'";

                    ResultSet rs = query.executeQuery(sql3);
                    while(rs.next()){
                        System.out.print(rs.getString("product_id"));
                        System.out.print(". ");
                        System.out.print(rs.getString("product_name"));
                        System.out.print(" price is ");
                        System.out.println(rs.getString("product_price"));
                    }
                }
                int choice2 = Integer.parseInt(reader.readLine());
                String sql = "select product_price from products WHERE product_id = " + "'" + choice2 + "'";
                ResultSet rs = query.executeQuery(sql);
                if(rs.next()){
                    cost = rs.getDouble("product_price");
                }
                System.out.print("Count: ");
                int count = Integer.parseInt(reader.readLine());
                order.setTotalCost((int) (cost * count));
                System.out.print("Do you wish to continue selecting products? Y/N: ");
                continueChoice = reader.readLine();
            }
            while (continueChoice.equalsIgnoreCase("Y"));

            if (strategy == null) {
                System.out.println("Please, select a payment method:" + "\n" +
                        "1 - PalPay" + "\n" +
                        "2 - Credit Card");
                String paymentMethod = reader.readLine();

                if (paymentMethod.equals("1")) {
                    strategy = new PayPal();
                } else {
                    strategy = new PayByCreditCard();
                }

                order.processOrder(strategy);

                System.out.print("Pay " + order.getTotalCost() + " tenge or Continue shopping? P/C: ");
                String proceed = reader.readLine();
                if (proceed.equalsIgnoreCase("P")) {


                    if (strategy.pay(order.getTotalCost())) {
                        System.out.println("Payment has been successful.");
                    } else {
                        System.out.println("FAIL! Please, check your data.");
                    }

                    order.setClosed();
                }
            }
        }
    }
}

