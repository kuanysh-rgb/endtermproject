package project;
import javax.xml.transform.Result;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;


public class PayPal implements PayStrategy {
    private final BufferedReader READER = new BufferedReader(new InputStreamReader(System.in));
    private String email;
    private String password;
    private double amountofmoney;
    private boolean signedIn;

    public double getAmountofmoney() {
        return amountofmoney;
    }

    public void setAmountofmoney(double amountofmoney) {
        this.amountofmoney = amountofmoney;
    }




    @Override
    public boolean pay(int paymentAmount) {
        if (signedIn) {
            System.out.println("Paying " + paymentAmount + " using PayPal.");
            setAmountofmoney(getAmountofmoney()-paymentAmount);
            System.out.print("Your balance is: ");
            System.out.println(getAmountofmoney());
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void collectPaymentDetails() {
        try {
            while (!signedIn) {

                if (verify()) {
                    System.out.println("Data verification has been successful.");
                } else {
                    System.out.println("Wrong email or password!");
                }
            }
        } catch (IOException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
    }
    private boolean verify() throws ClassNotFoundException, SQLException, IOException {
        System.out.print("Enter the user's email: ");
        email = READER.readLine();
        System.out.print("Enter the password: ");
        password = READER.readLine();
        String url = "jdbc:mysql://localhost:3307/admin?serverTimezone=UTC";
        String user = "root";
        String dbpassword = "7854";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection myConn = DriverManager.getConnection(url,user,dbpassword);
        Statement query = myConn.createStatement();
        String sql = "select * from paypal_users WHERE user_email =" + "'"+ email +"' and user_password = " + "'" + password +"'";
        ResultSet rs = query.executeQuery(sql);
        try {
            while (rs.next()) {
                amountofmoney = rs.getDouble("amount_of_money");
                signedIn = true;
                return signedIn;

            }
        }catch(Exception e){
            return false;
        }
        finally {
            rs.close();
        }
        return false;

    }
    private void setSignedIn(boolean signedIn) {
        this.signedIn = signedIn;
    }

}
